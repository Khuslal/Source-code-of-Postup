<?php
session_start();
include 'db_conn.php'; // Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in
include 'isUserLoggedin.php';
$username = $_SESSION['username'];

// Fetch posts from the database
$sql_posts = "SELECT fname, username, post_title, category, post_text, image_url, video_url, created_at FROM post ORDER BY post_id DESC";
$stmt_posts = $conn->prepare($sql_posts);
if (!$stmt_posts) {
    die('Database Error : ' . $conn->error);
}
$stmt_posts->execute();
$posts_result = $stmt_posts->get_result();
$posts = $posts_result->fetch_all(MYSQLI_ASSOC);
$stmt_posts->close();

?>

<!DOCTYPE html>
<html>

<head>
    <title>homepage</title>
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <?php include 'header.php'; ?>
    <main>
        <h2>Home</h2>
        <div id="posts">
            <?php foreach ($posts as $post): ?>
                <div class="post">
                    <p>Uploaded at: <?php echo htmlspecialchars($post['created_at']); ?></p>
                    <h2><?php echo htmlspecialchars($post['post_title']); ?></h2>
                    <p><?php echo htmlspecialchars($post['category']); ?></p>
                    <p><?php echo nl2br(htmlspecialchars($post['post_text'])); ?></p>
                    <?php if ($post['image_url']): ?>
                        <img src="<?php echo htmlspecialchars($post['image_url']); ?>" alt="Image">
                    <?php endif; ?>
                    <?php if ($post['video_url']): ?>
                        <video controls>
                            <source src="<?php echo htmlspecialchars($post['video_url']); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </main>
    <?php
    // Close the database connection
    $conn->close();
    ?>
</body>

</html>