<?php
include 'db_conn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    // Hash the password before storing it in the database
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if username already exists
    $check_user = $conn->prepare('SELECT * FROM users WHERE username = ?');
    $check_user->bind_param("s", $username);
    $check_user->execute();
    $check_user->store_result();

    if ($check_user->num_rows > 0) {
        $user_exist = "Username already exists.";
    } else {
        // Insert new user if username does not exist
        $new_user = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $new_user->bind_param("ss", $username, $password);

        if ($new_user->execute()) {
            // Set session variables upon successful signup
            session_start();
            $_SESSION['username'] = $username;
            $_SESSION['loggedin'] = true;

            // Redirect to setProfile.php page
            header("Location: setProfile.php");
            exit();
        } else {
            echo "Error: " . $new_user->error;
        }
        $new_user->close();
    }
    $check_user->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Signup</title>
    <link rel="stylesheet" href="css/signup.css">
</head>

<body>
    <main>
        <div class="container">
            <form action="" method="post">
                <h5>Please Signup To Continue</h5>
                <?php if (isset($user_exist)) : ?>
                    <p style="color:red;"><?php echo $user_exist; ?></p>
                <?php endif; ?>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" placeholder="username" required>
                <br>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="password" required>
                <br>
                <button type="submit">Signup</button>
                <a href="index.php" id="signuplink">Click here to login</a>
            </form>
        </div>
    </main>
</body>

</html>