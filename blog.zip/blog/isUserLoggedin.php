<?php
include 'db_conn.php';
// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || !$_SESSION['loggedin']) {
    header('Location: login.php');
    exit();
}
$username = $_SESSION['username'];
?>
