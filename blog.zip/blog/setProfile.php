<?php
session_start();
include 'db_conn.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in
include 'isUserLoggedin.php';
// $_SESSION['username'] is set as $username in isUserLoggedin.php
?>

<!DOCTYPE html>
<html>

<head>
    <title>Set Profile</title>
    <link rel="stylesheet" href="css/setProfile.css">
</head>

<body>
    <main>
        <header>
            <h1>Postup</h1>
            <nav>
                <a href="logout.php">Logout</a>
            </nav>
        </header>
        <div class="edit-container">
            <h2>Edit Profile</h2>
            <form id="editProfileForm" action="profile.php" method="post">
                <label for="nameInput">Name:</label>
                <input type="text" id="nameInput" name="fname" required>

                <label for="emailInput">Email:</label>
                <input type="email" id="emailInput" name="email" required>

                <label for="phoneInput">Phone:</label>
                <input type="tel" id="phoneInput" name="phone" required>

                <label for="bioInput">Bio:</label>
                <textarea id="bioInput" name="bio"></textarea>

                <button type="submit">Save Changes</button>
            </form>
        </div>
    </main>
</body>

</html>